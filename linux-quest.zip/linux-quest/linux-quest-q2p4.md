## Quest 2: Part 4 The... End?

Now you have made it this far, lets look into editing some files. 

there are several things that are consistent with any Linux Distro, and text editors is not one of them

Personally i prefer Nano, but Vi is an option, Vi doesn't always come with each Linux Distro.

